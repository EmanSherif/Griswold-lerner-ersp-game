using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Continue3 : MonoBehaviour
{
  public void levelFour() {
    SceneManager.LoadScene("levelFour");
  }
}
