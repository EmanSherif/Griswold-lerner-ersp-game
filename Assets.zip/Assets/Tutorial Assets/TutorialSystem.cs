using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TutorialSystem : MonoBehaviour
{
    public Text levelCode;

    public Button Continue;

    // Start is called before the first frame update
    void Start()
    {
      //Instantiate(levelCode, pos, rot) as Text;
    }
}
