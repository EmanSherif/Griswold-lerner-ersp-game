﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Continue1 : MonoBehaviour
{
  public void levelTwo() {
    SceneManager.LoadScene("levelTwo");
  }
}
