﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class continue6 : MonoBehaviour
{
  public void levelSeven() {
    SceneManager.LoadScene("LevelSeven");
  }
}
